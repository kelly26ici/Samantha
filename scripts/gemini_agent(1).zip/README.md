# gemini_agent

A minimal, modular LLM tool-agent: Gemini (new `google-genai` chats API) +
Tavily web search + an appointment-booking tool.

## Layout

```
agent/
  config.py          # settings, all env vars in one place
  logging_config.py  # loguru -> stdout, works with Render's log tail
  llm_client.py       # Gemini chat session wrapper + tenacity retries
  executor.py          # validates + runs one tool call, isolated from the LLM loop
  orchestrator.py      # the agent loop: send -> check for tool calls -> execute -> repeat
  main.py              # CLI entrypoint
  tools/
    base.py             # ToolRegistry -- the single extension point
    search_tool.py      # Tavily web_search
    booking_tool.py     # book_appointment
    __init__.py         # imports every tool module so it self-registers
```

## Why it's structured this way

Nothing outside `tools/` ever imports a specific tool. `executor.py` and
`orchestrator.py` only talk to `registry`. That means:

- **Adding a tool**: write `agent/tools/your_tool.py` (pydantic args model +
  `@registry.register(...)` decorated function), add one import line to
  `agent/tools/__init__.py`. Nothing else changes.
- **Changing a tool's signature**: edit its args model. The Gemini function
  schema, validation, and dispatch all regenerate automatically from it.
- **Removing a tool**: delete the file + its import line.
- **Swapping providers** (e.g. Tavily -> another search API, or the booking
  backend): only touch the one tool file's internals -- its `name`,
  `args_model`, and return shape (`{"ok": bool, ...}`) are the contract the
  rest of the system relies on.

## Running it

```bash
pip install -r requirements.txt
cp .env.example .env   # fill in GEMINI_API_KEY and TAVILY_API_KEY
python -m agent.main
```

## Design notes

- **Gemini chats API**: `client.chats.create(...)` + `chat.send_message(...)`
  is used instead of manually replaying full history through
  `generate_content` on every turn -- the SDK keeps history for you.
- **Manual function calling**: tool schemas are declared explicitly via
  `FunctionDeclaration` (not Python-callable auto-calling), so every tool
  call is validated and logged before it runs -- required for a booking
  tool you don't want the model executing blind.
- **tenacity**: retries live at the two points that talk to the network
  (the Gemini call in `llm_client.py`, the Tavily/booking calls inside each
  tool) with exponential backoff, instead of hand-rolled retry loops.
- **loguru**: one `configure_logging()` call, stdout only, `enqueue=True`
  so logging never blocks the request path -- this is what shows up live
  in Render's log tail.
- **Circuit breaker**: `MAX_TOOL_HOPS` caps how many tool-call round trips
  a single `ask()` can take, so a model stuck calling tools in a loop can't
  run away.
- **Tool contract**: every handler returns a plain `dict` with an `"ok"`
  key and never raises -- the executor also catches unexpected exceptions
  as a second safety net, so one flaky tool can't take down the agent loop.

## Adding a third tool (example)

```python
# agent/tools/weather_tool.py
from pydantic import BaseModel, Field
from .base import registry

class WeatherArgs(BaseModel):
    city: str = Field(..., description="City name")

@registry.register(
    name="get_weather",
    description="Get current weather for a city.",
    args_model=WeatherArgs,
)
def get_weather(city: str) -> dict:
    ...
    return {"ok": True, "city": city, "temp_c": 24}
```

Then in `agent/tools/__init__.py`:

```python
from . import booking_tool, search_tool, weather_tool  # noqa: F401
```

That's the entire change.
