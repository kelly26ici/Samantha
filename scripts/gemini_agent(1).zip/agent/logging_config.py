"""One place to configure logging. Render (and most PaaS log tails) just
read stdout, so we log there -- unbuffered, structured, colorized locally
and plain in production."""
import sys

from loguru import logger

from .config import settings


def configure_logging() -> None:
    logger.remove()  # drop loguru's default handler so we control format once
    logger.add(
        sys.stdout,
        level=settings.log_level,
        colorize=True,
        enqueue=True,  # thread/async safe, non-blocking -- important under load
        backtrace=False,
        diagnose=False,
        format=(
            "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
            "<level>{level: <8}</level> | "
            "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
            "<level>{message}</level>"
        ),
    )
