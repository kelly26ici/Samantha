"""LLM agent package.

Import lazily -- `from agent.orchestrator import Agent` -- rather than
re-exporting from here, so importing the package doesn't force settings
(env vars) to load until you actually build an Agent.
"""
