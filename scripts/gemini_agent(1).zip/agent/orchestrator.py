"""The orchestration loop. This is the only piece that knows about *all*
the other pieces (llm client, executor, registry) -- everything else only
knows about the registry. Swap tools, swap the model, swap the search
provider: this file doesn't change.
"""
from google.genai import types
from loguru import logger

from .config import settings
from .executor import ToolExecutor
from .llm_client import GeminiClient
from .tools import registry

SYSTEM_INSTRUCTION = (
    "You are a helpful assistant with access to tools for web search and "
    "booking appointments. Use them whenever they would improve your answer. "
    "Always confirm booking details back to the user before considering the "
    "task done."
)


class Agent:
    def __init__(self) -> None:
        self._llm = GeminiClient()
        self._executor = ToolExecutor()
        self._chat = self._llm.create_chat(
            tools=[registry.as_gemini_tool],
            system_instruction=SYSTEM_INSTRUCTION,
        )
        logger.info(f"Agent ready with tools: {registry.names()}")

    def ask(self, message: str) -> str:
        response = self._llm.send(self._chat, message)

        for hop in range(1, settings.max_tool_hops + 1):
            function_calls = getattr(response, "function_calls", None)
            if not function_calls:
                break

            logger.info(f"Hop {hop}: executing {len(function_calls)} tool call(s)")
            tool_responses = [self._executor.run(call) for call in function_calls]
            parts = [types.Part(function_response=fr) for fr in tool_responses]
            response = self._llm.send(self._chat, parts)
        else:
            logger.warning(f"Hit max_tool_hops={settings.max_tool_hops}; returning last response")

        return response.text or "(no response text)"
