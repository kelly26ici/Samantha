"""The single extension point for tools.

To add a new tool:
  1. Create `agent/tools/your_tool.py`.
  2. Define a pydantic `BaseModel` describing its arguments.
  3. Write a plain function and decorate it with `@registry.register(...)`.
  4. Add one import line in `agent/tools/__init__.py`.

Nothing in the executor, orchestrator, or llm client ever needs to change --
they only ever talk to `registry`, never to individual tool modules.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Type

from google.genai import types
from loguru import logger
from pydantic import BaseModel


@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    args_model: Type[BaseModel]
    handler: Callable[..., dict]

    def to_declaration(self) -> types.FunctionDeclaration:
        schema = self.args_model.model_json_schema()
        schema.pop("title", None)
        # Gemini's schema doesn't understand pydantic's "$defs" refs for
        # simple flat models, which is all we use here -- keep tool arg
        # models flat (str/int/float/bool fields) and this stays a non-issue.
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=schema,
        )


class ToolRegistry:
    """A tiny in-memory registry. Tools self-register on import; everything
    else (schema generation, dispatch) is derived from it."""

    def __init__(self) -> None:
        self._tools: dict[str, ToolSpec] = {}

    def register(self, name: str, description: str, args_model: Type[BaseModel]):
        def decorator(func: Callable[..., dict]) -> Callable[..., dict]:
            if name in self._tools:
                raise ValueError(f"Tool '{name}' is already registered")
            self._tools[name] = ToolSpec(name, description, args_model, func)
            logger.info(f"Registered tool: {name}")
            return func

        return decorator

    def get(self, name: str) -> ToolSpec:
        try:
            return self._tools[name]
        except KeyError as exc:
            raise KeyError(f"Unknown tool requested: '{name}'") from exc

    def names(self) -> list[str]:
        return list(self._tools.keys())

    @property
    def declarations(self) -> list[types.FunctionDeclaration]:
        return [spec.to_declaration() for spec in self._tools.values()]

    @property
    def as_gemini_tool(self) -> types.Tool:
        """The whole registry, packaged as the single `Tool` object Gemini expects."""
        return types.Tool(function_declarations=self.declarations)


registry = ToolRegistry()
