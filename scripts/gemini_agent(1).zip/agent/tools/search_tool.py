from loguru import logger
from pydantic import BaseModel, Field
from tavily import TavilyClient
from tenacity import retry, stop_after_attempt, wait_exponential

from ..config import settings
from .base import registry

_client = TavilyClient(api_key=settings.tavily_api_key)


class WebSearchArgs(BaseModel):
    query: str = Field(..., description="The search query")
    max_results: int = Field(5, ge=1, le=10, description="Number of results to return")


@retry(
    wait=wait_exponential(multiplier=1, min=1, max=10),
    stop=stop_after_attempt(3),
    reraise=True,
)
def _search(query: str, max_results: int) -> dict:
    logger.debug(f"Tavily search: {query!r} (max_results={max_results})")
    return _client.search(query=query, max_results=max_results)


@registry.register(
    name="web_search",
    description="Search the live web for current information using Tavily.",
    args_model=WebSearchArgs,
)
def web_search(query: str, max_results: int = 5) -> dict:
    """Handlers always return a plain dict -- never raise -- so a flaky
    upstream API can't crash the agent loop."""
    try:
        raw = _search(query=query, max_results=max_results)
        results = [
            {"title": r.get("title"), "url": r.get("url"), "content": r.get("content")}
            for r in raw.get("results", [])
        ]
        logger.info(f"web_search: {len(results)} results for {query!r}")
        return {"ok": True, "results": results}
    except Exception as exc:  # noqa: BLE001 -- deliberately broad, see docstring
        logger.exception(f"web_search failed for query={query!r}")
        return {"ok": False, "error": str(exc)}
