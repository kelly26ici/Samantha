"""Importing this package registers every tool.

Adding a tool = write the module (see search_tool.py / booking_tool.py as
templates) + add one import line here. Nothing downstream changes.
Removing a tool = delete its file + its import line here.
"""
from .base import registry
from . import booking_tool, search_tool  # noqa: F401  (imported for side-effect: registration)

__all__ = ["registry"]
