from datetime import datetime, timezone

from loguru import logger
from pydantic import BaseModel, Field, field_validator
from tenacity import retry, stop_after_attempt, wait_exponential

from .base import registry


class BookAppointmentArgs(BaseModel):
    name: str = Field(..., description="Full name of the person booking")
    date: str = Field(..., description="Appointment date, format YYYY-MM-DD")
    time: str = Field(..., description="Appointment time, 24h format HH:MM")
    reason: str = Field("", description="Reason for the appointment")

    @field_validator("date")
    @classmethod
    def _valid_date(cls, v: str) -> str:
        datetime.strptime(v, "%Y-%m-%d")
        return v

    @field_validator("time")
    @classmethod
    def _valid_time(cls, v: str) -> str:
        datetime.strptime(v, "%H:%M")
        return v


@retry(
    wait=wait_exponential(multiplier=1, min=1, max=10),
    stop=stop_after_attempt(3),
    reraise=True,
)
def _persist_booking(payload: dict) -> str:
    # Swap this for a real integration: Google Calendar, Cal.com, a DB
    # insert, etc. It's isolated + retried so the swap never touches the
    # tool's public contract below.
    logger.debug(f"Persisting booking: {payload}")
    return f"BKG-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"


@registry.register(
    name="book_appointment",
    description="Book an appointment for a user on a given date and time.",
    args_model=BookAppointmentArgs,
)
def book_appointment(name: str, date: str, time: str, reason: str = "") -> dict:
    try:
        booking_id = _persist_booking({"name": name, "date": date, "time": time, "reason": reason})
        logger.info(f"Booked {booking_id} for {name} on {date} {time}")
        return {"ok": True, "booking_id": booking_id, "date": date, "time": time}
    except Exception as exc:  # noqa: BLE001
        logger.exception(f"book_appointment failed for name={name!r}")
        return {"ok": False, "error": str(exc)}
