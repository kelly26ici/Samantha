"""Central config. All secrets/env vars live here and nowhere else."""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    gemini_api_key: str
    gemini_model: str = "gemini-2.5-flash"
    tavily_api_key: str

    log_level: str = "INFO"
    max_tool_hops: int = 6  # circuit breaker against runaway tool-call loops


settings = Settings()
