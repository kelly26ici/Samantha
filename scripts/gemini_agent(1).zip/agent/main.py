import sys

from loguru import logger

from .logging_config import configure_logging
from .orchestrator import Agent


def main() -> None:
    configure_logging()
    agent = Agent()
    logger.info("Agent ready. Type 'exit' to quit.")

    while True:
        try:
            user_input = input("you> ").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not user_input or user_input.lower() in {"exit", "quit"}:
            break

        try:
            reply = agent.ask(user_input)
        except Exception:
            logger.exception("Agent failed to produce a response")
            reply = "Sorry, something went wrong on my end."

        print(f"agent> {reply}")

    logger.info("Shutting down.")


if __name__ == "__main__":
    sys.exit(main())
