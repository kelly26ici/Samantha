"""Thin wrapper around the Gemini `Client().chats` interface (the newer,
stateful chat-session API) rather than repeated one-shot generateContent
calls with manually replayed history. All retry/backoff logic for talking
to the model lives here, once, via tenacity."""
from google import genai
from google.genai import types
from loguru import logger
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from .config import settings

# Broad on purpose: network hiccups, 429s, and transient 5xxs from the API
# should all be retried the same way. Narrow this to genai's specific
# exception types if you want different behavior per error class.
RETRYABLE = (Exception,)


class GeminiClient:
    def __init__(self) -> None:
        self._client = genai.Client(api_key=settings.gemini_api_key)

    def create_chat(self, tools: list[types.Tool], system_instruction: str | None = None):
        config = types.GenerateContentConfig(
            tools=tools,
            system_instruction=system_instruction,
            temperature=0.3,
        )
        return self._client.chats.create(model=settings.gemini_model, config=config)

    @retry(
        wait=wait_exponential(multiplier=1, min=2, max=20),
        stop=stop_after_attempt(4),
        retry=retry_if_exception_type(RETRYABLE),
        reraise=True,
    )
    def send(self, chat, message):
        """`message` may be a plain string (user turn) or a list of
        `types.Part` (e.g. function responses being sent back)."""
        logger.debug(f"-> Gemini: {message!r}")
        response = chat.send_message(message)
        logger.debug(f"<- Gemini: {getattr(response, 'text', None)!r}")
        return response
