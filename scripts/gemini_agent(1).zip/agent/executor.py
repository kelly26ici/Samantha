"""Runs a single tool call end to end: look up -> validate args -> execute.

Isolated on purpose -- a bad/unknown tool call or a handler exception can
never crash the orchestrator loop; it turns into a structured error the
model gets back and can react to."""
from google.genai import types
from loguru import logger
from pydantic import ValidationError

from .tools import registry


class ToolExecutor:
    def run(self, call: types.FunctionCall) -> types.FunctionResponse:
        name = call.name
        raw_args = dict(call.args or {})
        logger.info(f"Tool call: {name}({raw_args})")

        try:
            spec = registry.get(name)
        except KeyError as exc:
            logger.error(str(exc))
            return self._response(name, {"ok": False, "error": str(exc)})

        try:
            validated = spec.args_model(**raw_args)
        except ValidationError as exc:
            logger.warning(f"Invalid args for '{name}': {exc}")
            return self._response(name, {"ok": False, "error": f"invalid arguments: {exc}"})

        try:
            result = spec.handler(**validated.model_dump())
        except Exception as exc:  # noqa: BLE001 -- handlers should self-guard, but belt & suspenders
            logger.exception(f"Tool '{name}' raised unexpectedly")
            result = {"ok": False, "error": str(exc)}

        return self._response(name, result)

    @staticmethod
    def _response(name: str, payload: dict) -> types.FunctionResponse:
        return types.FunctionResponse(name=name, response=payload)
